$(document).ready(function () {
    $('#global_back').show();
});
function global_back(){
    $('#global_back').hide();
    var module = $('#main-heading-bar').text();
    if (module === 'Create Invoice'){
        cancelCreateInvoiceForm()
    }
    if (module === 'Preview Invoice'){
        $('#main-heading-bar').html('Invoices');
        backToInvoiceList()
    }
    if (module === 'Edit Invoice'){
        $('#main-heading-bar').html('Preview Invoices');
        var table_no = $('#invoice_table_id').val();
        backToPreviewInvoicePage(table_no)
    }
    // Quotation
    if (module === 'Create Quotation'){
        cancelCreateQuotationForm()
    }
    if (module === 'Preview Quotation'){
        backToQuotationList()
    }
    if (module === 'Edit Quotation'){
        var table_no = $('#quotation_table_id').val();
        backToPreviewQuotationPage(table_no)
    }

    // Payment Receipt
    if (module === 'Create Payment Receipt'){
        cancelCreatePaymentForm()
    }
    if (module === 'Preview Payment Receipt'){
        backToPaymentList()
    }
    if (module === 'Edit Payment Receipt'){
        var table_no = $('#payment_record_table_id').val();
        backToPreviewPaymentPage(table_no)
    }

    // Credit Note
    if (module === 'Create Credit Note'){
        backToHomeCreditNote()
    }
    if (module === 'Preview Credit Note'){
        backToCreditNoteList()
    }
    if (module === 'Edit Credit Note'){
        var table_no = $('#credit_note_table_id').val();
        backToPreviewCreditNote(table_no)
    }
    // Delivery Challan
    if (module === 'Create Delivery Challan'){
        cancelCreateDeliveryChallanForm()
    }
    if (module === 'Preview Delivery Challan'){
        backToDeliveryChallanList()
    }
    if (module === 'Edit Delivery Challan'){
        var table_no = $('#delivery_challan_table_id').val();
        backToPreviewDeliveryChallanPage(table_no)
    }

    // Purchase
    if (module === 'Create Purchase'){
        cancelCreatePurchaseForm()
    }
    if (module === 'Preview Purchase'){
        backToPurchaseList()
    }
    if (module === 'Edit Purchase') {
        var table_no = $('#purchase_table_id').val();
        backToPreviewPurchasePage(table_no)
    }

    // Payments Made
    if (module === 'Create Payments Made'){
        cancelCreatePaymentForm()
    }
    if (module === 'Preview Payments Made'){
        backToDeliveryChallanList()
    }
    if (module === 'Edit Payments Made') {
        var table_no = $('#vendor_payment_table_id').val();
        backToPreviewPaymentPage(table_no)
    }

    // Debit Note
    if (module === 'Create Debit Note'){
        backToHomeDebitNote()
    }
    if (module === 'Preview Debit Note'){
        backToDebitNoteList()
    }
    if (module === 'Edit Debit Note') {
        var table_no = $('#debit_note_table_id').val();
        backToPreviewDebitNote(table_no)
    }

    // Purchase Order
    if (module === 'Create Purchase Order'){
        cancelCreatePurchaseOrderForm()
    }
    if (module === 'Preview Purchase Order'){
        backToPurchaseOrderList()
    }
    if (module === 'Edit Purchase Order') {
        var table_no = $('#purchase_order_table_id').val();
        backToPreviewPurchaseOrderPage(table_no)
    }
    // Purchase Order
    if (module === 'Create Reverse Charge'){
        cancelCreateReverseChargeForm()
    }
    if (module === 'Preview Reverse Charge'){
        backToReverseChargeList()
    }
    if (module === 'Edit Reverse Charge') {
        var table_no = $('#reverse_charge_table_id').val();
        backToPreviewReverseChargePage(table_no)
    }

    if (module === 'Ledgers'){
        goBack()
    }
    if (module === 'Individual Product Sales Report'){
        product_sales_report()
    }
    if (module === 'Individual Product Purchase Report'){
        product_purchase_report()
    }
    if (module === 'Individual Party Sales Report'){
        party_sales_report()
    }
    if (module === 'Individual Party Purchase Report'){
        party_purchase_report()
    }
    if (module === 'HSN Invoice Report'){
        $('#page_hsn_report').click();
    }
}