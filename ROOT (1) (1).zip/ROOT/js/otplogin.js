$(document).ready(function () {
    // Initially hide signup, forgot, verify forgot card
    $('#col_signup_form').hide();
    $('#col_forgot_password_form').hide();
    $('#col_otp_forgot_password').hide();
    // Initially hide OTP card
    $('#col_otp_form').hide();
    // Hide referral code input field
    $('#row_referral_code').hide();
    // Initially hide loader
    $('#loader').hide();

    $("#mobile").keyup(function(event) {
        if (event.keyCode === 13) {
            sendOTP(event);
        }
    });

    $("#otp").keyup(function(event) {
        if (event.keyCode === 13) {
            verifyOTP(event);
        }
    });
});

/*** ************************* ***/
/*** Custom methods ***/
/*** ************************ ***/

/*** This is used to submit login form ***/
var timer_count = 0
function sendOTP(event) {
    event.preventDefault();
    if(validateLogin()){
        $('#loader').show();
        if (timer_count > 0){
            resend_otp_timer(timer_count)
        }
        document.getElementById("login_with_otp").disabled = true;
        var mobile = document.getElementById("mobile").value;
        var login_data = {};
        login_data["phone"] = mobile;
        $.ajax({
            method: "POST",
            url: "/v4/account/auth/get-otp/",
            data: login_data,
            success: function (response, response_msg, xhr) {
                if (xhr.status === 200) {
                    document.getElementById("mobile").disabled = true;
                    $('#login_with_otp').show();
                    $('#btn_send_otp').hide();
                    $('#btn_login').show();
                    $('#otp').focus();
                    localStorage.setItem("otp_token", response.otp_token);
                    timer_count = timer_count + 1
                }
            },
            error: function(error){
                Materialize.toast(error.responseJSON.message, 3000, 'rounded','blue');
            },
            complete: function () {
                document.getElementById("login_with_otp").disabled = false;
                $('#loader').hide().fadeOut(800);
            }
        });
    }
}

function verifyOTP(event) {
    event.preventDefault();
    if(validateOTP()){
        $('#loader').show();
        document.getElementById("btn_login").disabled = true;
        var otp = document.getElementById("otp").value;
        var otp_token = localStorage.getItem("otp_token");
        if (otp_token === "" || otp_token === null || otp_token === undefined ){
            Materialize.toast('Theres some issue please try again', 3000, 'rounded','blue');
            setTimeout(function(){
                window.location.href = '/web/login/'
            }, 2000);
            return false
        }

        var login_data = {};
        login_data["otp"] = otp;
        login_data["otp_token"] = otp_token;
        $.ajax({
            method: "POST",
            url: "/v4/account/auth/verify-otp/",
            data: login_data,
            success: function (response, response_msg, xhr) {
                if (xhr.status === 200) {
                    var today = new Date();
                    localStorage.clear();
                    localStorage.setItem("access_token", response.old_access_token);
                    localStorage.setItem("new_access_token", response.access_token);
                    localStorage.setItem("modal_download_app", 0);
                    localStorage.setItem("last_popup_shown_day", today.getDay());
                    localStorage.setItem("last_popup_shown_month", today.getMonth());
                    localStorage.setItem("last_popup_shown_year", today.getYear());
                    if (response.company_list.length > 0) {
                        localStorage.setItem("company_id", response.company_list[0].uuid);
                        window.location.href = '/web/home/';
                    }
                    else {
                        $('#row_login').hide();
                        getSectorList()
                        $('#div-sector-main').show();
                    }
                }
                else{
                    Materialize.toast(response_msg, 3000, 'rounded');
                    $('#otp').focus();
                }
            },
            error: function(error){
                Materialize.toast(error.responseJSON.otp, 3000, 'rounded','blue');
            },
            complete: function () {
                document.getElementById("btn_login").disabled = false;
                $('#loader').hide().fadeOut(800);
            }
        });
    }
}

function resend_otp_timer(){
    $("#span_send_otp").css("pointer-events", "none");
    var timeLeft = 60;
    var elem = document.getElementById('resend_otp_timer');
    var timerId = setInterval(countdown, 1000);
    function countdown() {
        if (timeLeft == -1) {
            clearTimeout(timerId);
            $('#resend_otp_timer').hide()
            $("#span_send_otp").css("pointer-events", "auto");
        } else {
            elem.innerHTML = timeLeft;
            timeLeft--;
        }
    }
}

// Validate Login Form
function validateLogin() {
    var get_mobile  = document.getElementById('mobile').value;
    if (get_mobile == null || get_mobile === ""){
        $('#mobile').focus();
        return false;
    }
    return true;
}

function validateOTP() {
    var get_otp  = document.getElementById('otp').value;
    if (get_otp == null || get_otp === ""){
        $('#otp').focus();
        return false;
    }
    return true;
}

function loginWithPassword(event) {
    event.preventDefault();
    window.location.href = '/web/login_with_password/';
}

function getSectorList() {
    $.ajax({
        url: '/v4/master/sector/',
        method: 'GET',
        data: {},
        success: function (response) {
            var html_data = "";
            for (i=0;i < response.results.length;i++){
                html_data += ' <div class="col s3 m3 l3">'+
                    ' <div class="card sector-card" style="background-color: white;cursor: pointer" id="'+response.results[i].id+'">'+
                    '<p>' +
                    '   <input type="checkbox" class="filled-in checkbox-get-sector-data" id="filled-in-box-' + response.results[i].id + '"  onclick="selectSector('+response.results[i].id+')"/>' +
                    '   <label for="filled-in-box-' + response.results[i].id + '"></label>' +
                    '   </p>' +
                    '   <div class="card-content center" style="overflow: auto"   onclick="selectSector('+response.results[i].id+')">' +
                    '   <img height="80px" src="'+response.results[i].image+'" alt="'+response.results[i].name+'"/>'+
                    '   <p class="center" style="font-size: 14px !important;"><br>'+response.results[i].name+'</p>' +
                    '   </div>' +
                    '   </div>'+
                    '   </div>';
            }
            $('#sector_details').html(html_data);
        }
    })
}

function selectSector(sector_id){
    var new_access_token = localStorage.getItem("new_access_token");
    $.ajax({
        method: "POST",
        url: "/v4/company/",
        data: {'name': 'My Company', 'sector':sector_id},
        beforeSend: function (xhr) {
            xhr.setRequestHeader ("Authorization", "Bearer " + new_access_token);
        },
        success: function () {
            window.location.href = '/web/home/';
        },
        error: function(error){
            Materialize.toast(error.responseJSON.message, 3000, 'rounded','blue');
        },
    })
}