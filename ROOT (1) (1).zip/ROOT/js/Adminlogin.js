$(document).ready(function () {
    // Initially hide signup, forgot, verify forgot card
    $('#col_signup_form').hide();
    $('#col_forgot_password_form').hide();
    $('#col_otp_forgot_password').hide();
    // Initially hide OTP card
    $('#col_otp_form').hide();
    // Hide referral code input field
    $('#row_referral_code').hide();
    // Initially hide loader
    $('#loader').hide();

    $("#mobile").keyup(function (event) {
        if (event.keyCode === 13) {
            sendOTP(event);
        }
    });

    $("#otp").keyup(function (event) {
        if (event.keyCode === 13) {
            verifyOTP(event);
        }
    });
});

/*** ************************* ***/
/*** Custom methods ***/
/*** ************************ ***/

/*** This is used to submit login form ***/
var timer_count = 0
function sendOTP(event) {
    event.preventDefault();
    if (validateLogin()) {
        $('#loader').show();
        
        var mobile = document.getElementById("uname").value;
        var pass = document.getElementById("reg_password").value;
        var login_data = {};
        login_data["phone"] = mobile;
        login_data["pass"] = pass;

        $.ajax({
            
            url: "AdminVerify.jsp",
            data: login_data,
            success: function (result) {

                window.location.href = 'Admin_Dashboard';

            },
            complete: function () {
                document.getElementById("btn_login_with_password").disabled = false;
                $('#loader').hide().fadeOut(800);
            }
        });
    }
}

// Validate Login Form
function validateLogin() {

    var get_mobile = document.getElementById('uname').value;
    var password = document.getElementById('reg_password').value;

    if (get_mobile == "" || get_mobile == null) {
        $('#uname').focus();
        return false;
    }
    if (password == "" || password == null) {
        $('#reg_password').focus();
        return false;
    }
    return true;
   
   
}



