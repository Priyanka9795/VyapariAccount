$(document).ready(function () {
    // Initially hide OTP card
    $('#userDetails').hide();
    // Initially hide loader
    $('#loader').hide();
    // Hide referral code input field
    $('#row_referral_code').hide();
});

/*** ************************* ***/
/*** Custom methods ***/
/*** ************************ ***/
function checkValidPassword(){
    var password = document.getElementById("reg_password").value;
    var regexp = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*#?&]{6,}$/;
    // let regexp = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/;

    $('#password_validation').css('display', 'block');
    var result = regexp.test(password)
    if (result){
        $('#password_validation').hide();
        $('#signup_btn').prop('disabled', false);
    }
    else{
        $('#password_validation').css('display', 'block');
        $('#signup_btn').prop('disabled', true);
    }
}
/*** This is used to submit signup form ***/
function signupSubmit() {
   
    if(validateSignUp()){
        $('#loader').show();
        // Disable Button after click
        document.getElementById("signup_btn").disabled = true;
        document.getElementById("signup_btn").value = "Please wait...";
        // Get login data
        var company_name = document.getElementById("reg_company_name").value;
        var mobile = document.getElementById("reg_mobile").value;
        var password = document.getElementById("reg_password").value;
        
      
        // Call AJAX for signup
          
        $.ajax({
            
            url: "SignupData.jsp",
         
            cache: false,
            setCookies: "",
            data: {"mobile":mobile,"password":password,"company_name":company_name},
            success: function (result) {    
                   // alert(company_name);
             
                    $('#col_signup_form').hide();
                    $('#userDetails').show(500);
                    
                },
            complete: function () {
                document.getElementById("signup_btn").disabled = false;
                $('#loader').hide().fadeOut(800);
            }
        });
    }
}

/*** This is used to show/hide referral field ***/
function referralShowHide() {
    var get_checked_value = document.getElementById('checkbox_referral').checked;
    if (get_checked_value){
        $('#row_referral_code').show(200);
    }
    else{
        $('#row_referral_code').hide(200);
    }
}

// Validate Sign up form
function validateSignUp() {
   

var phoneError = document.getElementById('phone-error');
    var get_company_name  = document.getElementById('reg_company_name').value;
    var get_mobile  = document.getElementById('reg_mobile').value;
    var password  = document.getElementById('reg_password').value;
    var cpassword  = document.getElementById('reg_cpassword').value;
    var flag_referral  = document.getElementById('checkbox_referral').checked;
    var get_referral  = document.getElementById('referral_code').checked;
    if (get_company_name == "" || get_company_name == null){
        $('#reg_company_name').focus();
        return false;
    }
    
  if (get_mobile == ""|| get_mobile== null) {
     return false;
  }
    if (password == "" || password == null){
        $('#reg_password').focus();
        return false;
    }
    if (password != cpassword){
        Materialize.toast("Password and confirm password should be same.", 2000, 'rounded');
        $('#cpassword').focus();
        return false;
    }
    if (flag_referral){
        if(get_referral == null || get_referral == ""){
            $('#referral_code').focus();
            return false;
        }
    }
    return true;
}


/*** This is used to submit OTP form ***/
function otpSubmit() {
    
    var name  = document.getElementById("name").value;
    var address  = document.getElementById("address").value;
    
    if (name == "" || address == ""){
        $('#name').focus();
        return false;
    }
    // Call AJAX for Verify OTP
    $('#loader').show();
     alert("You details are saved ");
    $.ajax({
        url: "userDetails.jsp",
        method:"POST",
         cache: false,
            setCookies: "",
        data: {"name":name,"address":address},

        success: function (result) {
         
                window.location.href = 'client_Dashboard';
              
            },
          
        
        complete: function () {
            document.getElementById("otp_verify_btn").disabled = false;
            $('#loader').hide().fadeOut(800);
        }
    });
}