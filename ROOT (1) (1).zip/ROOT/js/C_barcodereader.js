

var barcode = "";
var interval;
document.addEventListener("keydown", function (evt) {
  if (interval) clearInterval(interval);
  if (evt.code == "Enter") {
    if (barcode) {
      handleBarcode(barcode);
    }
    barcode = "";
    return;
  }
  if (evt.key != "Shift") barcode += evt.key;
  interval = setInterval(() => (barcode = ""), 20);
});

function handleBarcode(scanned_barcode) {
  var barcode_data = scanned_barcode;
  $.ajax({
    url: "/product/fetch_product_data_with_barcode/",
    type: "GET",
    data: { barcode_data: barcode_data, access_token: access_token },
    dataType: "json",
    success: (response) => {
      var heading = document.getElementById("main-heading-bar").innerHTML;
      if (heading == "Inventory") {
        productDetails(response.product_id);
      } else if (
        heading == "Quotations" ||
        "Invoices" ||
        "Credit Note" ||
        "Delivery Challans" ||
        "Purchases" ||
        "Debit Note" ||
        "Purchase Order" ||
        "Reverse Charge"
      ) {
        EditClickedProductData(response.product_id);
        document.getElementById("taxable_amount").innerHTML = "0";
        document.getElementById("amount").innerHTML = "0";
        document.getElementById("total_amount").innerHTML = "0";
      }
    },
    error: (error) => {
      var heading = document.getElementById("main-heading-bar").innerHTML;
      let li = document.getElementById("barcode");
      if (
        heading == "Quotations" ||
        "Invoices" ||
        "Credit Note" ||
        "Delivery Challans" ||
        "Purchases" ||
        "Debit Note" ||
        "Purchase Order" ||
        "Reverse Charge" ||
        "Inventory" ||
        "Products"
      ) {
        openProductModal();
        li.innerHTML = "Barcode - " + barcode_data;
        barcode_data = barcode_data.replace(/\D/g, "");
        $(product_item_code).val(barcode_data);
      }
    },
  });
}

function text_delete_on_modal_close() {
  let li = document.getElementById("barcode");
  li.innerHTML = "";
}
function tax_amount_total_delete_on_modal_close() {
  document.getElementById("taxable_amount").innerHTML = "0";
  document.getElementById("amount").innerHTML = "0";
  document.getElementById("total_amount").innerHTML = "0";
}