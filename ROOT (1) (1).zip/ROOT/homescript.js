$(document).ready(function () {

    var new_sector_code = "100";
    // Initialize collapstton
    $('.dropdown-button').dropdown({
            // inDuration: 300,
            // outDuration: 225,
            // constrainWidth: false, // Does not change width of dropdown to that of the activator
            // click: true, // Activate on hover
            hover: true, // Activate on hover
            // gutter: 0, // Spacing from edge
            // belowOrigin: false, // Displays dropdown below the button
            // alignment: 'left', // Displays dropdown with edge aligned to the left of button
            // stopPropagation: false // Stops event propagation
        }
    );
    /*** Initialize alert subscription modal  ***/
    $('#modal_subscribe_alert').modal({
        startingTop: '20%', // Starting top style attribute
    });
    // Initially hide AJAXLoader
    $("#AJAXLoader").hide();
    // Call Invoice List page on load
    var access_token = localStorage.getItem("access_token");
    $(".button-collapse").sideNav();
    $('#li_retail_invoices').hide();
    new_sector_code = localStorage.getItem("sector_code");
    localStorage.setItem('invoice_module_type', 0)
    if (new_sector_code === null)
    {
        new_sector_code = "100";
    }
    if (new_sector_code.toString() === '300'){
        $('#li_invoice').hide();
        $('#li_retail_invoices').addClass('active');
        $('#li_retail_invoices').show();
        page_retail_invoice();
    }
    else if (new_sector_code.toString() === '800'){
        $('#li_retail_invoices').show();
        page_invoice();
    }
    else{
        page_invoice();
    }
    
    
    $('#page_invoices').click(function (e) {
        localStorage.setItem('invoice_module_type', 0)
        $('#page_invoice').click();
    });
    $('#page_e_way_bill').click(function (e) {
        updateActiveMenuItem(this);
    });

    $('#page_invoice').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        // $("#AJAXLoader").show();
        localStorage.setItem('invoice_module_type', 0)
        // Call Invoice List
        $.ajax({
            
            data: {'access_token': access_token},
            url: "e-envoice.jsp",
            success: function (html_data) {
                var html = '<div id="div_1">';
                html += html_data;
                html += '</div>';
                $('#main').html(html);
            },
            complete: function () {
                // $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');

            },
            onStart: function () {
                $('.button-collapse').sideNav('hide');
            }
        });
    });

    $('#page_e_invoice').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        // Call Invoice List
        $.ajax({
            
            data: {'access_token': access_token, 'module_type': 2},
            url: "e_Invoice.jsp",
            success: function (html_data) {

                var html = '<div id="div_1">';
                html += html_data;
                html += '</div>';
                $('#main').html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');

            },
            onStart: function () {
                $('.button-collapse').sideNav('hide');
            }
        });
    });

    $('#page_buyer').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        // Call buyers List
        $.ajax({
           
            url: "masters/customers.jsp",
            success: function (html_data) {
                $('#main').html(html_data);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            },
            onStart: function () {
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    $('#page_product').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        // Call products List
        $.ajax({
            
            url: "masters/products.jsp",
            success: function (html_data) {
                $('#main').html(html_data);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    $('#purchase_details_report').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        // Call products List
        $.ajax({
            type: "GET",
            url: "/web/products/",
            success: function (html_data) {
                $('#main').html(html_data);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    $('#page_e_way_bill').click(function (e) {
      
        $("#AJAXLoader").show();
        // Call buyers List
        $.ajax({
            
            url: "sidePanel/bill.jsp",
            data: {'access_token': access_token, 'module_type': 1},
            success: function (html_data) {
                $('#main').html(html_data);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            },
            onStart: function () {
                $('.button-collapse').sideNav('hide');
            }
        });
    });


    $('#page_expense').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            
            url: "expanses.jsp",
            success: function (html_data) {
                $('#main').html(html_data);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    $('#page_quotation').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
           
            data: {'access_token': access_token},
            url: "quotation.jsp",
            success: function (html_data) {
                var html = '<div id="div_1">';
                html += html_data;
                html += '</div>';
                $('#main').html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    
     $('#page_proforma_invoice').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
           
            data: {'access_token': access_token},
            url: "proformainvoice.jsp",
            success: function (html_data) {
                var html = '<div id="div_1">';
                html += html_data;
                html += '</div>';
                $('#main').html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    
    //*********************call inventory on inventory click button***********************
    $('#page_inventory').click(function (e) {
        var access_token = localStorage.getItem("access_token");
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            
            url: "sidePanel/Purchase.jsp",
            data: {'access_token': access_token},
            success: function (html_data) {
                $('#main').html(html_data);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    $('#page_settings').click(function (e) {
        var access_token = localStorage.getItem("access_token");
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            type: "GET",
            url: "/web/settings/",
            data: {'access_token': access_token},
            cache: false,
            success: function (html_data) {
                $('#main').html(html_data);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    $('#page_reverse_charge').click(function (e) {
        var access_token = localStorage.getItem("access_token");
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            type: "GET",
            url: "purchases/reverse_charge.jsp",
            data: {'access_token': access_token},
            success: function (html_data) {
                $('#main').html(html_data);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });

    $('#page_subscription').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        // e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            type: "GET",
            url: "subscription.jsp",
            success: function (html_data) {
                $('#main').html(html_data);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    $('#page_purchase').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            
            data: {'access_token': access_token},
            url: "purchases/purchase.jsp",
            success: function (html_data) {
                var html = '<div id="div_1">';
                html += html_data;
                html += '</div>';
                $('#main').html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    $('#page_delivery_challan').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            
            data: {'access_token': access_token},
            url: "delivery_challan.jsp",
            success: function (html_data) {
                var html = '<div id="div_1">';
                html += html_data;
                html += '</div>';
                $('#main').html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    $("#page_product_sales_report").click(function (e) {
        $("#AJAXLoader").show();
        $.ajax({
            
            url: 'reports/product_sales_report.jsp',
            success: function (html_data) {
                var html = html_data;
                $("#main").html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $(".button-collapse").sideNav('hide');
            }
        });
    });
    $("#page_party_sales_report").click(function (e) {
        $("#AJAXLoader").show();
        $.ajax({
           
            url: 'reports/party_sales_report.jsp',
            success: function (html_data) {
                var html = html_data;
                $("#main").html(html_data);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $(".button-collapse").sideNav('hide');
            }
        });
    });
    $("#page_product_purchase_report").click(function (e) {
        $("#AJAXLoader").show();
        $.ajax({
            type: "GET",
            url: 'reports/product_purchase_report.jsp',
            success: function (html_data) {
                var html = html_data;
                $("#main").html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $(".button-collapse").sideNav('hide');
            }
        });
    });


    $("#page_party_purchase_report").click(function (e) {

        $("#AJAXLoader").show();
        $.ajax({
            type: "GET",
            url: 'reports/party_purchase_report.jsp',
            success: function (html_data) {
                var html = html_data;
                $("#main").html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $(".button-collapse").sideNav('hide');
            }
        });
    });
    $('#page_report').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        var access_token = localStorage.getItem("access_token");
        $.ajax({
            
            data: {'access_token': access_token},
            url: 'Reports.jsp',
            success: function (html_data) {
                var html = html_data;
                $("#main").html(html_data);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $(".button-collapse").sideNav('hide');
            }
        });
    });
    $('#page_finance_report').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        var access_token = localStorage.getItem("access_token");
        $.ajax({
            type: 'GET',
            data: {'access_token': access_token},
            url: '/web/trading/finance_report_home/',
            success: function (html_data) {
                var html = html_data;
                $("#main").html(html_data);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $(".button-collapse").sideNav('hide');
            }
        });
    });
    $('#page_seller').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $.ajax({
            
            url: "masters/vendor.jsp",
            success: function (html_data) {
                $('#main').html(html_data);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            },
            onStart: function () {
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    // Open Payment Record html page
    $('#page_payment_record').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            
            url: "paymentrecipt.jsp",
            success: function (html_data) {
                var html = '<div id="div_1">';
                html += html_data;
                html += '</div>';
                $('#main').html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });


    // Open Vendor Payment Record html page
    $('#page_vendor_payment').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
           
            url: "purchases/payment_made.jsp",
            success: function (html_data) {
                var html = '<div id="div_1">';
                html += html_data;
                html += '</div>';
                $('#main').html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });


//    this is po id for api call in home
    $('#page_purchase_order').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            
            data: {'access_token': access_token},
            url: "purchases/purchase_order.jsp",
            success: function (html_data) {
                var html = '<div id="div_1">';
                html += html_data;
                html += '</div>';
                $('#main').html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });


    //  Open Credit note list Page
    $('#page_credit_note').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            
            data: {'access_token': access_token},
            url: "creditnote.jsp",
            success: function (html_data) {
                var html = '<div id="div_1">';
                html += html_data;
                html += '</div>';
                $('#main').html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    $('#page_debit_note').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
           
            data: {'access_token': access_token},
            url: "purchases/debit_note.jsp",
            success: function (html_data) {
                var html = '<div id="div_1">';
                html += html_data;
                html += '</div>';
                $('#main').html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    $('#page_purchase_bill').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            type: "GET",
            data: {'access_token': access_token},
            url: "/web/purchase_bill/get/",
            success: function (html_data) {
                var html = '<div id="div_1">';
                html += html_data;
                html += '</div>';
                $('#main').html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });

    $('#page_ledger').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            type: "GET",
            data: {'access_token': access_token},
            url: "ledger.jsp",
            success: function (html_data) {
                var html = '<div id="div_1">';
                html += html_data;
                html += '</div>';
                $('#main').html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });

    $('#page_retail_invoice').click(function (e) {
        updateActiveMenuItem(this);
        // e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            
            data: {'access_token': access_token},
            url: "retail_invoice.jsp",
            success: function (html_data) {
                var html = '<div id="div_1">';
                html += html_data;
                html += '</div>';
                $('#main').html(html);
            },
            complete: function () {
                $("#AJAXLoader").hide().fadeOut(800);
                $('.button-collapse').sideNav('hide');
            }
        });
    });
    localStorage.setItem("refer_code", "");
    check_subscription()
});

$("#page_product_purchase_report").click(function (e) {
    $.ajax({
        type: "GET",
        url: 'reports/product_purchase_report.jsp',
        success: function (html_data) {
            var html = html_data;
            $("#main").html(html);
        },
        complete: function () {
            $("#AJAXLoader").hide().fadeOut(800);
            $(".button-collapse").sideNav('hide');
        }
    });
});
$("#page_party_purchase_report").click(function (e) {
    updateActiveMenuItem(this);
    e.stopImmediatePropagation();
    e.preventDefault();
    $("#AJAXLoader").show();
    $.ajax({
        type: "GET",
        url: 'reports/party_purchase_report.jsp',
        success: function (html_data) {
            var html = html_data;
            $("#main").html(html);
        },
        complete: function () {
            $("#AJAXLoader").hide().fadeOut(800);
            $(".button-collapse").sideNav('hide');
        }
    });
});

$('#page_seller').click(function (e) {
    updateActiveMenuItem(this);
    e.stopImmediatePropagation();
    e.preventDefault();
    $("#AJAXLoader").show();
    // Call Invoice List page on load
    $.ajax({
        type: "GET",
        url: "masters/vendor.jsp",
        success: function (html_data) {
            $('#main').html(html_data);
        },
        complete: function () {
            $("#AJAXLoader").hide().fadeOut(800);
            $('.button-collapse').sideNav('hide');
        },
        onStart: function () {
            $('.button-collapse').sideNav('hide');
        }
    });
});
$("#page_product_purchase_report").click(function (e) {
    $.ajax({
       
        url: 'reports/product_purchase_report.jsp',
        success: function (html_data) {
            var html = html_data;
            $("#main").html(html);
        },
        complete: function () {
            $("#AJAXLoader").hide().fadeOut(800);
            $(".button-collapse").sideNav('hide');
        }
    });
});
$("#page_party_purchase_report").click(function (e) {
    updateActiveMenuItem(this);
    e.stopImmediatePropagation();
    e.preventDefault();
    $("#AJAXLoader").show();
    $.ajax({
        
        url: 'reports/party_purchase_report.jsp',
        success: function (html_data) {
            var html = html_data;
            $("#main").html(html);
        },
        complete: function () {
            $("#AJAXLoader").hide().fadeOut(800);
            $(".button-collapse").sideNav('hide');
        }
    });
});

$('#page_seller').click(function (e) {
    updateActiveMenuItem(this);
    e.stopImmediatePropagation();
    e.preventDefault();
    $("#AJAXLoader").show();
    // Call sellers List page
    $.ajax({
        type: "GET",
        url: "masters/vendor.jsp",
        success: function (html_data) {
            $('#main').html(html_data);
        },
        complete: function () {
            $("#AJAXLoader").hide().fadeOut(800);
            $('.button-collapse').sideNav('hide');
        },
        onStart: function () {
            $('.button-collapse').sideNav('hide');
        }
    });
});

// This is used to update left container ul li active elements
function updateActiveMenuItem(clicked_obj) {
    $("#left_container_ul_menu li.active").removeClass("active");
    $('#left_container_ul_menu li').removeClass('active');
    $(clicked_obj).parent().addClass('active');
}

// Open create invoice html page
function page_create_invoice() {
    /*** Check If company is subscribed  ***/
    var is_subscription_expired = localStorage.getItem("is_subscription_expired")
    if(is_subscription_expired === "true"){
        $('#modal_subscribe_alert').modal('open');
        return false;
    }
    var dynamic_url = "page_create_invoice.jsp"
    sector_code = localStorage.getItem("sector_code");
    if (sector_code.toString() === '300'){dynamic_url = "retail_invoice.jsp"}
    // $("#AJAXLoader").show();
    $.ajax({
        type: "GET",
        url: dynamic_url,
        success: function (html_data) {
            $('#main').html(html_data);
        },
        complete: function () {
            // $("#AJAXLoader").hide().fadeOut(800);
        }
    });
    $('.button-collapse').sideNav('hide');
}

// Open expense html page
function page_expense() {
    $("#AJAXLoader").show();
    $.ajax({
        
        url: "expanses.jsp",
        success: function (html_data) {
            $('#main').html(html_data);
        },
        complete: function () {
            $("#AJAXLoader").hide().fadeOut(800);
        }
    });
    $('.button-collapse').sideNav('hide');
}

// Open subscription html page
// This function called inside modal alert subscription
function openSubscriptionPage() {
    $('#page_subscription').click();
}


var path_active_sales = false;
var path_active_purchase = false;
var path_active_master = false;
var count = 0
var count_sales = 0;
$(document).ready(function () {
    $('#sales').click(function () {
        $("#left_container_ul_menu li").removeClass("active");
        if (path_active_sales === true) {
            count_sales = count
        }
        path_active_sales = false;
        if (count_sales % 2 === 0) {
            $("#rotate_sales").css("transform", "rotate(90deg)");
        } else {
            $("#rotate_sales").css("transform", "rotate(1deg)");
        }
        count_sales += 1
        if ($('#li_invoice').hasClass('active') !== true) {
            var new_sector_code = localStorage.getItem("sector_code");
            if (new_sector_code.toString() === '300'){
                page_retail_invoice();
            }
            else if (new_sector_code.toString() === '800'){
                page_invoice();
            }
            else{
                page_invoice();
            }
            // $('#page_invoices').click();
        }
        $("#li_invoice").addClass("active");
    });
});
var count_purchase = 0;
$(document).ready(function () {
    $('#purchase').click(function () {
        // $("#left_container_ul_menu li").removeClass("active");
        if (path_active_purchase === true) {
            count_purchase = count
        }
        path_active_purchase = false;
        if (count_purchase % 2 === 0) {
            $("#rotate_purchase").css("transform", "rotate(90deg)");
        } else {
            $("#rotate_purchase").css("transform", "rotate(1deg)");
        }
        count_purchase += 1
        if ($('#li_purchase').hasClass('active') !== true) {
            $('#page_purchase').click();
        }
        $("#li_purchase").addClass("active");
    });
});
var count_master = 0;
$(document).ready(function () {
    $('#master').click(function () {
        // $("#left_container_ul_menu li").removeClass("active");
        if (path_active_master === true) {
            count_master = count
        }
        path_active_master = false;
        if (count_master % 2 === 0) {
            $("#rotate_masters").css("transform", "rotate(90deg)");
        } else {
            $("#rotate_masters").css("transform", "rotate(1deg)");
        }
        count_master += 1
        if ($('#li_buyer').hasClass('active') !== true) {
            $('#page_buyer').click();
        }
        $("#li_buyer").addClass("active");
    });
});

var count_settings = 0;
$(document).ready(function () {
    $('#settings').click(function () {
        if (path_active_master === true) {
            count_master = count
        }
        path_active_master = false;
        if (count_master % 2 === 0) {
            $("#rotate_settings").css("transform", "rotate(90deg)");
        } else {
            $("#rotate_settings").css("transform", "rotate(1deg)");
        }
        count_master += 1
        if ($('#li_template_settings').hasClass('active') !== true) {
            $('#page_template_settings').click();
        }
        $("#li_template_settings").addClass("active");
    });


    $('#page_inventory_settings').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
           
            url: "settings/inventory_setting.jsp",
            data:{access_token:access_token},
            cache:false,
            beforeSend:function () {
                $("#AJAXLoader").show();
            },
            success: function(html_data){
                $('#main').html(html_data);
            },
            complete:function () {
                $("#AJAXLoader").hide().fadeOut(800);
            }
        });
    });

    $('#page_merge_product').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            
            url: "settings/merge_product.jsp",
            data:{access_token:access_token},
            cache:false,
            beforeSend:function () {
                $("#AJAXLoader").show();
            },
            success: function(html_data){
                $('#main').html(html_data);
            },
            complete:function () {
                $("#AJAXLoader").hide().fadeOut(800);
            }
        });
    });

    $('#page_merge_buyer').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            
            url: "settings/merge_buyers.jsp",
            data:{access_token:access_token},
            cache:false,
            beforeSend:function () {
                $("#AJAXLoader").show();
            },
            success: function(html_data){
                $('#main').html(html_data);
            },
            complete:function () {
                $("#AJAXLoader").hide().fadeOut(800);
            }
        });
    });

    $('#page_merge_seller').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            
            url: "settings/merge_sellers.jsp",
            data:{access_token:access_token},
            cache:false,
            beforeSend:function () {
                $("#AJAXLoader").show();
            },
            success: function(html_data){
                $('#main').html(html_data);
            },
            complete:function () {
                $("#AJAXLoader").hide().fadeOut(800);
            }
        });
    });

    $('#page_category_settings').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            
            url: "settings/Expance_setting.jsp",
            data:{access_token:access_token},
            cache:false,
            beforeSend:function () {
                $("#AJAXLoader").show();
            },
            success: function(html_data){
                $('#main').html(html_data);
            },
            complete:function () {
                $("#AJAXLoader").hide().fadeOut(800);
            }
        });
    });

    $('#page_template_settings').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            
            url: "settings/change_template.jsp",
            data:{access_token:access_token},
            cache:false,
            beforeSend:function () {
                $("#AJAXLoader").show();
            },
            success: function(html_data){
                $('#main').html(html_data);
            },
            complete:function () {
                $("#AJAXLoader").hide().fadeOut(800);
            }
        });
    });

    $('#page_format').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
           
            url: "settings/change_format.jsp",
            data:{access_token:access_token},
            cache:false,
            beforeSend:function () {
                $("#AJAXLoader").show();
            },
            success: function(html_data){
                $('#main').html(html_data);
            },
            complete:function () {
                $("#AJAXLoader").hide().fadeOut(800);
            }
        });
    });

    $('#page_invoice_settings').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
           
            url: "settings/invoice_setting.jsp",
            data:{access_token:access_token},
            cache:false,
            beforeSend:function () {
                $("#AJAXLoader").show();
            },
            success: function(html_data){
                $('#main').html(html_data);
            },
            complete:function () {
                $("#AJAXLoader").hide().fadeOut(800);
            }
        });
    });

    $('#page_sector_settings').click(function (e) {
        updateActiveMenuItem(this);
        e.stopImmediatePropagation();
        e.preventDefault();
        $("#AJAXLoader").show();
        $.ajax({
            
            url: "settings/sector_setting.jsp",
            data:{access_token:access_token},
            cache:false,
            beforeSend:function () {
                $("#AJAXLoader").show();
            },
            success: function(html_data){
                $('#main').html(html_data);
            },
            complete:function () {
                $("#AJAXLoader").hide().fadeOut(800);
            }
        });
    });
});

function openCreateInvoicePage() {
    /*** Check If company is subscribed  ***/
    var is_subscription_expired = localStorage.getItem("is_subscription_expired")
    if(is_subscription_expired === "true"){
        $('#modal_subscribe_alert').modal('open');
        return false;
    }
    // Call Create Invoice page
    
    $.ajax({
       
        url: "page_create_invoice.jsp",
        data:{'access_token':access_token},
        cache:false,
        beforeSend:function () {
            $("#AJAXLoader").show();
        },
        success: function(html_data){
            $('#main').html(html_data);
        },
        complete:function () {
            $("#AJAXLoader").hide().fadeOut(800);
        }
    });
}

function page_retail_invoice(obj){
    updateActiveMenuItem(obj);
    $("#AJAXLoader").show();
    $.ajax({
       
        data: {'access_token': access_token},
        url: "retail_invoice.jsp",
        success: function (html_data) {
            var html = '<div id="div_1">';
            html += html_data;
            html += '</div>';
            $('#main').html(html);
        },
        complete: function () {
            $("#AJAXLoader").hide().fadeOut(800);
            $('.button-collapse').sideNav('hide');
        }
    });
}
function page_invoice(obj){
    updateActiveMenuItem(obj);
    // $("#AJAXLoader").show();
    // Call Invoice List
    $.ajax({
        type: "GET",
        data: {'access_token': access_token},
        url: "/web/invoice/all/",
        success: function (html_data) {

            var html = '<div id="div_1">';
            html += html_data;
            html += '</div>';
            $('#main').html(html);
        },
        complete: function () {
            // $("#AJAXLoader").hide().fadeOut(800);
            $('.button-collapse').sideNav('hide');

        },
        onStart: function () {
            $('.button-collapse').sideNav('hide');
        }
    });
}

function check_subscription() {
    var token = localStorage.getItem("access_token");
    $.ajax({
        type: "GET",
        data: {'access_token': token},
        url: "/helper/check_user_subscription/",
        beforeSend: function () {
            $("#AJAXLoader").show();
        },
        success: function (result) {
            var is_subscription_expired = false
            var sector_code = 100
            if (result.success === true) {
                is_subscription_expired = result.is_subscription_expired
                sector_code = result.sector_code
            }
            localStorage.setItem("is_subscription_expired", is_subscription_expired);
            localStorage.setItem("sector_code", sector_code);
        },
        complete: function () {
            $("#AJAXLoader").hide().fadeOut(800);

        },
    });
}


function show_download_app_popup() {
    var isMobile = false; //initiate as false
    // device detection
    if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent)
        || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0,4))){
        isMobile = true;
    }
    if(isMobile){
        if (localStorage.getItem("popup_download_app") === null) {
            // Show Popup
            $('#modal_download_app').modal('open');
            localStorage.setItem('popup_download_app', 1);
            var today = new Date();
            localStorage.setItem("last_popup_shown_day", today.getDay());
            localStorage.setItem("last_popup_shown_month", today.getMonth());
            localStorage.setItem("last_popup_shown_year", today.getYear());
        }
        else{
            var get_value = localStorage.getItem("popup_download_app");
            if (get_value === 0){
                // Show Popup
                $('#modal_download_app').modal('open');
                localStorage.setItem('popup_download_app', 1);
                var today = new Date();
                localStorage.setItem("last_popup_shown_day", today.getDay());
                localStorage.setItem("last_popup_shown_month", today.getMonth());
                localStorage.setItem("last_popup_shown_year", today.getYear());
            }
            else{
                var last_popup_shown_day = parseInt(localStorage.getItem("last_popup_shown_day"));
                var last_popup_shown_month = parseInt(localStorage.getItem("last_popup_shown_month"));
                var last_popup_shown_year = parseInt(localStorage.getItem("last_popup_shown_year"));
                var today = new Date();
                if (last_popup_shown_day !== today.getDay() || last_popup_shown_month !== today.getMonth() || last_popup_shown_year !== today.getYear()){
                    $('#modal_download_app').modal('open');
                    localStorage.setItem('popup_download_app', 1);
                    localStorage.setItem("last_popup_shown_day", today.getDay());
                    localStorage.setItem("last_popup_shown_month", today.getMonth());
                    localStorage.setItem("last_popup_shown_year", today.getYear());
                }
            }
        }
    }
}